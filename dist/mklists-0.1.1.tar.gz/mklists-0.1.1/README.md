# mklists

Rearrange plain-text to-do lists by tweaking rules

## Installation

In root directory of Github repo:

* `$ pip3 install --editable .`          

## Tests

* `$ pytest .`
* `$ python -m doctest -v tests/doctest_linkify.txt`

## Virtual environment

* 
