mklists

Rebuild plain-text todo lists using rules
