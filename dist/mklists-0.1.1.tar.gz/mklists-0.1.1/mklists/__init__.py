"""Marks as package directory for Python."""
